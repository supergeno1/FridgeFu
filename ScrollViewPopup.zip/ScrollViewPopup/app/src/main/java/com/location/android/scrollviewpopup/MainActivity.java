package com.location.android.scrollviewpopup;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;



public class MainActivity extends AppCompatActivity {
    public class DeleteIngredientAdapter extends ArrayAdapter<String> {
        public DeleteIngredientAdapter(Context context, ArrayList<String> ingredients) {
            super(context, 0, ingredients);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
            String food = getItem(position);
            // Check if an existing view is being reused, otherwise inflate the view
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.popup2, parent, false);
            }
            // Lookup view for data population
            TextView tvName = (TextView) convertView.findViewById(R.id.food);
//            TextView tvHome = (TextView) convertView.findViewById(R.id.tvHome);
            // Populate the data into the template view using the data object
            tvName.setText(food);
//            tvHome.setText(user.hometown);
            // Return the completed view to render on screen
            return convertView;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void startPopup(View view) {
        // Do something in response to button click

        ArrayList<String> ingredients = new ArrayList<>();
        ingredients.add("tomato");
        ingredients.add("cheese");

        showAlertbox(ingredients);

    }

    public void goSingleRecipe(View view) {
        // Do something in response to button click
        Intent intent = new Intent(getBaseContext(), SingleRecipe.class);
        startActivity(intent);
    }


    public void showAlertbox(ArrayList<String> ingredients) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        View rowList = getLayoutInflater().inflate(R.layout.popup, null);
        ListView listView = rowList.findViewById(R.id.removeIngredients);
        DeleteIngredientAdapter adapter = new DeleteIngredientAdapter(this, ingredients);
        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        alertDialog.setView(rowList);
        AlertDialog dialog = alertDialog.create();
        dialog.show();
    }
}
