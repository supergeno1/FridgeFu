package com.location.android.scrollviewpopup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SingleRecipe extends AppCompatActivity {

    public class Ingredients {

        public String name;
        public String amount;

        public Ingredients(String name, String amount) {
            this.name = name;
            this.amount = amount;
        }
    }

    public class Steps {

        public String name;
        public String amount;

        public Steps(String name, String amount) {
            this.name = name;
            this.amount = amount;
        }
    }


    public class ServingsAdapter extends ArrayAdapter<String> {

        public ServingsAdapter(Context theContext, List<String> objects, int theLayoutResId) {
            super(theContext, theLayoutResId, objects);
        }

        @Override
        public int getCount() {
            // don't display last item. It is used as hint.
            int count = super.getCount();
            return count > 0 ? count - 1 : count;
        }
    }


    public class ExpandIngredientAdapter extends ArrayAdapter<Ingredients> {
        public ExpandIngredientAdapter(Context context, ArrayList<Ingredients> ingredients) {
            super(context, 0, ingredients);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
            Ingredients ingredient = getItem(position);
            // Check if an existing view is being reused, otherwise inflate the view
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.ingredient, parent, false);
            }
            // Lookup view for data population
            TextView name = (TextView) convertView.findViewById(R.id.name);
            TextView amount = (TextView) convertView.findViewById(R.id.amount);

            // Populate the data into the template view using the data object
            name.setText(ingredient.name);
            amount.setText(ingredient.amount);

            return convertView;
        }
    }

    public class ExpandStepsAdapter extends ArrayAdapter<Steps> {
        public ExpandStepsAdapter(Context context, ArrayList<Steps> steps) {
            super(context, 0, steps);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
            Steps step = getItem(position);
            // Check if an existing view is being reused, otherwise inflate the view
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.step, parent, false);
            }
            // Lookup view for data population
            TextView name = (TextView) convertView.findViewById(R.id.name);
            TextView amount = (TextView) convertView.findViewById(R.id.amount);

            // Populate the data into the template view using the data object
            name.setText(step.name);
            amount.setText(step.amount);

            return convertView;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_recipe);

        //get List of ingredients and steps
        ArrayList<Ingredients> ingredientsList = new ArrayList<>();
        ingredientsList.add(new Ingredients("tomato", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));
        ingredientsList.add(new Ingredients("cheese", "1 cup"));



        SingleRecipe.ExpandIngredientAdapter adapterIngredients = new SingleRecipe.ExpandIngredientAdapter(this, ingredientsList);

        ListView listView = (ListView) findViewById(R.id.ingredientlist);
        listView.setAdapter(adapterIngredients);

        //SERVINGS
        Spinner spinner = (Spinner) findViewById(R.id.servings);
        List<String> objects = new ArrayList<String>();
        objects.add("     1");
        objects.add("     2");
        objects.add("     3");
        // add hint as last item
        objects.add("Servings");
//        spinner.setOnItemClickListener();
        ServingsAdapter servingsAdapter = new ServingsAdapter(this, objects, android.R.layout.simple_spinner_item);
        servingsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinnerFilmType = (Spinner) findViewById(R.id.servings);
        spinner.setAdapter(servingsAdapter);
        // show hint
        spinner.setSelection(servingsAdapter.getCount());



        //Steps
        ArrayList<Steps> stepsList = new ArrayList<>();
        stepsList.add(new Steps("Step 1: cook the past", "40 mins"));
        stepsList.add(new Steps("Step 2: cook the past", "40 mins"));
        stepsList.add(new Steps("Step 3: cook the past", "40 mins"));
        stepsList.add(new Steps("Step 4: cook the past", "40 mins"));
        stepsList.add(new Steps("Step 5: cook the past", "40 mins"));
        stepsList.add(new Steps("Step 6: cook the past", "40 mins"));
        stepsList.add(new Steps("Step 7: cook the past", "40 mins"));
        stepsList.add(new Steps("Step 8: cook the past", "40 mins"));

        SingleRecipe.ExpandStepsAdapter adapterSteps = new SingleRecipe.ExpandStepsAdapter(this, stepsList);
        ListView listView2 = (ListView) findViewById(R.id.stepslist);
        listView2.setAdapter(adapterSteps);



    }
}
